function testFunc() {
    return {
        name : 'RonnieJ',
        position : 'Lecturer'
    };
}

var ret = testFunc();

console.log(ret);